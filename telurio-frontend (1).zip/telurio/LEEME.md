# Telurio — Front-end (MPA)

Sitio web gamificado para estudiantes de química. Front-end completo en
**HTML + CSS + JavaScript Vanilla**, sin dependencias ni compilación:
se abre directamente en el navegador o con cualquier servidor estático.

---

## Cómo probarlo

Opción A — servidor local (recomendado):

```bash
cd telurio
python3 -m http.server 8000
# abrir http://localhost:8000
```

Opción B — doble clic en `index.html` (también funciona).

> Las tipografías (Fredoka y Nunito) se cargan desde Google Fonts; sin
> internet el sitio funciona igual con las fuentes de respaldo del sistema.

---

## Estructura de carpetas

```
telurio/
├── index.html            → Inicio de sesión
├── inicio.html           → Panel del alumno (progreso + actividades)
├── anuncios.html         → Anuncios
├── tabla.html            → Tabla de competición
├── foro.html             → Foro comunitario (crear temas)
├── clase.html            → Selector de clase (actual / archivadas)
├── clase-detalle.html    → Semanas del bimestre  (?curso=q3 | ?curso=q2)
├── juego.html            → Crucigrama  (?curso=q3&semana=2&nivel=1)
├── tienda.html           → Tienda atómica (buffos + skins)
├── css/
│   ├── estilos.css       → Estilos globales (variables, layout, componentes)
│   └── juego.css         → Estilos propios del crucigrama
├── js/
│   ├── estado.js         → Estado y persistencia (sesión, átomos, compras…)
│   ├── datos.js          → DATOS DE DEMOSTRACIÓN (simulan la API)
│   ├── principal.js      → Cabecera, menú lateral, avisos (compartido)
│   ├── sesion.js         → Lógica del ingreso
│   ├── inicio.js         → Panel del alumno
│   ├── tabla.js          → Ranking
│   ├── foro.js           → Foro
│   ├── clase-detalle.js  → Rejilla de semanas
│   ├── tienda.js         → Compras y buffos
│   └── juego.js          → Motor del crucigrama (tablero, reloj, puntaje)
└── img/                  → Imágenes del diseño original (nombres normalizados)
```

---

## Conexión con el back-end

Buscá el comentario **`TODO BACKEND`** en el código: cada uno marca el punto
exacto donde reemplazar la lógica local por un `fetch()` a tu API.

| Función del front | Archivo | Endpoint sugerido |
|---|---|---|
| Ingreso usuario/contraseña | `js/sesion.js` | `POST /api/sesion` |
| Ingreso con Google (GIS) | `js/sesion.js` → `#boton-google` | OAuth de Google |
| Ingreso con Microsoft (MSAL) | `js/sesion.js` → `#boton-microsoft` | OAuth de Microsoft |
| Saldo de átomos | `js/estado.js` | `GET/POST /api/usuario/atomos` |
| Progreso del bimestre | `js/datos.js` → `PROGRESO_BIMESTRE` | `GET /api/alumno/progreso` |
| Actividades pendientes | `js/datos.js` → `ACTIVIDADES_PENDIENTES` | `GET /api/alumno/actividades` |
| Ranking | `js/datos.js` → `RANKING` | `GET /api/tabla?curso=` |
| Temas del foro | `js/foro.js` / `datos.js` | `GET/POST /api/foro/temas` |
| Catálogo y compras | `js/tienda.js` / `datos.js` | `GET /api/tienda/productos`, `POST /api/tienda/compras` |
| Niveles del crucigrama | `js/datos.js` → `NIVELES_CRUCIGRAMA` | `GET /api/juego/niveles` |
| Puntaje al ganar | `js/juego.js` → `terminarPartida()` | `POST /api/progreso` |

Notas importantes:

- **Todos los formularios y botones tienen `id` en español y descriptivos**
  (`#formulario-sesion`, `#campo-usuario`, `#boton-google`,
  `#formulario-tema`, `#comprar-tiempo-15`, etc.).
- Hoy la persistencia usa `localStorage` (prefijo `telurio_`) para que el
  sitio sea 100 % funcional sin servidor. Al conectar la API, la validación
  de saldo y las compras deben verificarse **del lado del servidor**.
- La sesión se protege en `js/principal.js` mediante
  `Estado.exigirSesion()`: sin usuario, cualquier página interna redirige a
  `index.html`. Reemplazalo por la verificación del token real.

---

## El juego (crucigrama)

- 3 niveles de química definidos en `js/datos.js` (`NIVELES_CRUCIGRAMA`).
  Agregar un nivel = agregar un objeto con sus palabras y coordenadas.
- Validación palabra por palabra, navegación con flechas del teclado,
  reloj de 10 minutos, puntos por palabra (+5) y bono de nivel (+10).
- Los **buffos** comprados en la tienda (multiplicador de tiempo o de
  puntos) se consumen automáticamente en la partida siguiente.

## Créditos de diseño

Interfaz basada en las maquetas del Proyecto Telurio
(Emiliano Álvarez, Dante Castiglione y Luca Butvilofsky).
Colorimetría clave: `#006969` en degradado con `#16AE84`.
